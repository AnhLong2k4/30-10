﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using KiemTra3010.Models;

namespace KiemTra3010
{
    public partial class Form1 : Form
    {
        private List<Product> products = new List<Product>();
        private ShoppingCart cart = new ShoppingCart();

        public Form1()
        {
            InitializeComponent();
            LoadProducts();
            DisplayProducts();
        }

        private void LoadProducts()
        {
            // Thêm các sản phẩm mẫu với đường dẫn ảnh đúng
            products.Add(new Product("Sản phẩm 1", 100000, 1, Image.FromFile("Screenshot 2024-09-14 183502.png")));
            products.Add(new Product("Sản phẩm 2", 200000, 1, Image.FromFile("Screenshot 2024-09-14 183502.png")));
            products.Add(new Product("Sản phẩm 3", 150000, 1, Image.FromFile("Screenshot 2024-09-14 183502.png")));
        }

        private void DisplayProducts()
        {
            foreach (var product in products)
            {
                ListViewItem item = new ListViewItem(product.Name);
                item.SubItems.Add(product.Price.ToString());
                item.SubItems.Add(product.Quantity.ToString());
                item.Tag = product;

                listViewProducts.Items.Add(item);
            }
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (listViewProducts.SelectedItems.Count > 0)
            {
                var selectedProduct = (Product)listViewProducts.SelectedItems[0].Tag;
                cart.AddProduct(selectedProduct);
                UpdateCart();
            }
        }

        private void btnRemoveFromCart_Click(object sender, EventArgs e)
        {
            if (listViewCart.SelectedItems.Count > 0)
            {
                var selectedProduct = (Product)listViewCart.SelectedItems[0].Tag;
                cart.RemoveProduct(selectedProduct);
                UpdateCart();
            }
        }

        private void UpdateCart()
        {
            listViewCart.Items.Clear();
            foreach (var product in cart.Products)
            {
                ListViewItem item = new ListViewItem(product.Name);
                item.SubItems.Add(product.Price.ToString());
                item.SubItems.Add(product.Quantity.ToString());
                listViewCart.Items.Add(item);
            }
            lblTotalPrice.Text = "Tổng giá: " + cart.GetTotalPrice() + " VND";
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Tổng giá trị đơn hàng: " + cart.GetTotalPrice() + " VND", "Xác nhận thanh toán");
            cart.Clear();
            UpdateCart();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listViewProducts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddToCart_Click_1(object sender, EventArgs e)
        {
            if (listViewProducts.SelectedItems.Count > 0)
            {
                var selectedProduct = (Product)listViewProducts.SelectedItems[0].Tag;
                cart.AddProduct(selectedProduct);
                UpdateCart();
            }
        }
    }
}
